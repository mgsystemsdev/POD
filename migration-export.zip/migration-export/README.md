# Migration export (dashboard UI + architecture docs)

This tree is a **read-only extraction** from the parent monorepo. Nothing here replaces or changes runtime behavior of the original project.

| Path | Contents |
|------|----------|
| `dashboard-ui/` | Static HTML/JS/CSS dashboard, tech-stack composer assets, and the Vite + React SPA scaffold. |
| `architecture-docs/` | ADRs, workspace architecture map, system audits, and blueprint contracts. |
| `migration-notes/` | Dependency inventory, recommended greenfield layout, and items to delete after cutover. |

Start with `migration-notes/dashboard-dependencies.md`, then `recommended-new-dashboard-structure.md`.
