# Recommended structure for a new dashboard repository

This is guidance for a **greenfield frontend** that consumes a **separate** API (REST today; event-driven tomorrow). It does not prescribe a backend stack.

---

## 1. Repository layout (frontend-only)

```text
apps/web/                    # or repo root if single-app
  public/
  src/
    app/                     # routes, layouts, providers
    components/              # shared primitives (buttons, tables, dialogs)
    features/
      projects/
      tasks/
      blueprints/
      ...                    # one folder per domain tab / workflow
    lib/
      api-client.ts          # fetch wrapper, auth headers, base URL
      query-keys.ts          # cache key factory for React Query (or equivalent)
    types/                   # DTOs shared with OpenAPI-generated types (optional)
  index.html
  vite.config.ts
package.json
```

**Rule:** feature folders own **UI + hooks + small mappers**; they must not import SQLite, workers, or filesystem utilities.

---

## 2. React architecture

| Layer | Responsibility |
|-------|----------------|
| **Routes** | React Router (or file-based routing) maps URL → layout; `/projects/:projectId/tasks`, etc. |
| **Layouts** | Shell: sidebar, header, outlet for tab content. |
| **Data** | Prefer **TanStack Query** (or SWR) for server state; **Zustand** or React context only for UI-only state (active tab, modal open, column prefs). |
| **Forms** | React Hook Form + zod for mutations (task create/edit, project admin). |
| **Design system** | Tailwind + headless UI (Radix) or MUI — pick one; the legacy monolith used custom CSS variables (dark theme, accent colors per tab). |

Avoid porting the monolith as a single 2k-line component; extract **table**, **toast**, **modal**, **sidebar** first.

---

## 3. API client boundaries

```text
lib/api-client.ts     → transport only (base URL, JSON, errors, X-API-Key)
features/tasks/api.ts → task-specific paths and DTO mapping
```

- **Single `ApiError` type** that normalizes `{ detail }` from FastAPI-style responses.
- **No business rules** in the client beyond serialization (e.g. priority P1–P5 ↔ API convention).
- **Environment:** `VITE_API_BASE_URL` for dev/prod; do not hardcode `127.0.0.1:8765`.
- **Auth:** always explicit (`Authorization` or `X-API-Key` from secure storage), not “hope the env key is empty.”

Later, replace `features/*/api.ts` internals with generated clients from **OpenAPI** once the new backend exposes a schema.

---

## 4. Event-driven UI updates

Legacy UI: **30s polling** + manual refresh.

**Near term:** keep polling for low-risk parity; tune interval per tab (tasks vs static blueprints).

**Medium term:**

- **SSE:** one channel per user or per project for `task.updated`, `run.finished`, `proposed_action.created`. UI invalidates React Query keys on events.
- **WebSocket:** use if bidirectional commands (e.g. cancel run) are required on the same channel.

**Principle:** server pushes **facts** (IDs + version or etag); client refetches or patches cache — avoid pushing huge HTML/JSON blobs.

---

## 5. Separation from backend implementation

| Concern | Frontend owns | Backend owns |
|---------|---------------|--------------|
| Validation UX | Zod schemas mirroring API | Authoritative validation + DB constraints |
| Optimistic updates | Optional for task status | Durability, audit log |
| File paths (`root_path`) | Display, copy-to-clipboard | Path existence, sandboxing |
| Agent execution | Progress UI | Workers, subprocess, LLM calls |

The dashboard is an **observer and control plane**, not an orchestration engine.

---

## 6. Static tech stack composer

Keep `tech-stack-app.js` as either:

- an **iframe** or route that loads the existing ES module, or
- a **React port** that imports the same `tech-stack-catalog.js` data file as JSON/TS module.

The catalog is declarative and easy to convert to `techStackCatalog.ts` for type safety.

---

## 7. Testing

- **MSW** (Mock Service Worker) in dev/storybook with handlers matching `dashboard-dependencies.md`.
- **Contract tests:** optional Pact or OpenAPI diff in CI against the new API.

This yields a frontend repo that ships independently of Python services, SQLite, or cron layout.
