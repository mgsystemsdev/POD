# Remove after migration

Items tied to the **old monorepo runtime** or **export scaffolding** that should **not** carry into a clean production frontend repository.

---

## 1. Legacy backend assumptions

- Hardcoded **same-origin `/api`** paths without a configurable base URL (partially addressed in this export via `window.__DASHBOARD_API_PREFIX__` — remove the global once you use env-based config inside a proper client module).
- Reliance on **no API key** in local dev for the static dashboard HTML.
- **Vite proxy** pointing at `127.0.0.1:8765` — development-only; delete or replace when the new API URL is known.
- **Monolithic globals** in `index.html` (`allTasks`, `allProjects`, etc.) — do not port the pattern; only port the UX and data requirements.

---

## 2. Temporary compatibility hacks (this export only)

- **`fetchProjects()` stub** returning `[]` in `dashboard-ui/react-vite-spa/src/App.tsx` — replace with real implementation, then delete the stub.
- **Dual path story:** `static-html/` monolith vs `react-vite-spa/` — pick one product surface for the new repo and delete the other copy if redundant.
- **Comments** injected in exported `index.html` / `tech-stack-app.js` pointing back to `migration-notes/` — optional to strip for polish.

---

## 3. Files and folders that should NOT survive into the new frontend repo

| Item | Reason |
|------|--------|
| `server.py`, `requirements.txt` | FastAPI + Python stack — not part of a frontend-only repo. |
| `scripts/emit_tech_stack_catalog.py` | Build script for catalog; may move to **backend** or **tooling** repo, not the web app. |
| `ui/node_modules/`, `ui/dist/` | Regenerate with `npm ci` / `npm run build`; never commit (this export already omits them). |
| `ui/package-lock.json` | Optional: regenerate in the new repo after dependency bump (commit policy is team choice). |
| **SQLite / `system/services/`** | Entire backend domain — excluded from this export on purpose. |
| **Operational docs** not copied here | e.g. `start_dashboard.sh`, cron docs, worker logs — not frontend concerns. |

---

## 4. Documentation to archive, not to ship with the web app

The **`architecture-docs/`** tree belongs in **engineering docs** (Notion, internal docs site, or ADR repo), not inside `apps/web/public/`. After migration:

- Link to ADRs from the new repo’s `README` or `docs/`.
- Do not bundle large audit PDFs/markdown into the production JS bundle.

---

## 5. Security footguns to eliminate in the new system

- Serving **write-capable** task APIs from a host that shares cookies with untrusted sites (use authn/z and CSRF strategy appropriate to your deployment).
- Logging **sensitive** task bodies to browser extensions or third-party error reporters — scrub PII before client-side logging.

Use this list as a PR checklist when the new dashboard first goes to production.
