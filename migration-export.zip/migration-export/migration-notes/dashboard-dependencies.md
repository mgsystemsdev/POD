# Dashboard dependencies (export inventory)

This document describes what the **exported UI** expected from the **legacy FastAPI dashboard** (`agent-system-base/system/dashboard/server.py`, run from `agent-services` with `system/services/` on `PYTHONPATH`). It is a contract checklist for rebuilding the backend elsewhere.

---

## 1. Transport and auth

| Topic | Behavior |
|-------|----------|
| Base URL | Same origin as the HTML app; all XHR/fetch paths are under `/api` unless `window.__DASHBOARD_API_PREFIX__` is set (migration export only). |
| API key | If `AGENTS_API_KEY` is set server-side, every `/api/*` request must send matching `X-API-Key`. The static HTML app does **not** attach this header today — it only works when the key is unset or when a reverse proxy injects it. **New SPA should add explicit auth.** |
| Content type | JSON bodies use `Content-Type: application/json`. |
| Errors | FastAPI often returns `{ "detail": "..." }` or structured `detail` for 409s; the vanilla `api()` helper parses `detail` for user-facing errors. |

---

## 2. REST routes implemented by `server.py`

These routes exist on the backend; the **main monolithic `index.html`** uses a subset (listed in §3).

### Projects

| Method | Path |
|--------|------|
| GET | `/api/projects` |
| POST | `/api/projects` |
| GET | `/api/projects/{id}` |
| PUT | `/api/projects/{id}` |
| PATCH | `/api/projects/{id}` |
| DELETE | `/api/projects/{id}` |
| PUT | `/api/projects/{id}/tech-stack` |

### Tasks

| Method | Path |
|--------|------|
| GET | `/api/tasks` (query: `project_id`, `status`) |
| POST | `/api/tasks` |
| GET | `/api/tasks/{id}` |
| PUT | `/api/tasks/{id}` |
| DELETE | `/api/tasks/{id}` |
| GET | `/api/tasks/{id}/runs` |
| POST | `/api/tasks/{id}/complete` |

### Runs

| Method | Path |
|--------|------|
| GET | `/api/runs` (query: `project_id`) |

### Per-project resources

| Method | Path |
|--------|------|
| GET/POST | `/api/projects/{id}/backlog` |
| GET/POST | `/api/projects/{id}/approvals` |
| GET | `/api/projects/{id}/validations` |
| GET/POST | `/api/projects/{id}/blueprints` |
| GET/POST | `/api/projects/{id}/decisions` |
| GET/POST | `/api/projects/{id}/requirements` |
| GET/PUT | `/api/projects/{id}/memory/{key}` (`PUT` key is path segment) |
| GET/POST | `/api/projects/{id}/session-logs` |
| GET | `/api/projects/{id}/session-logs/latest` |
| GET | `/api/projects/{id}/execution-trace` |

### Blueprints (global id)

| Method | Path |
|--------|------|
| GET/PUT/DELETE | `/api/blueprints/{blueprint_id}` |

### Proposed actions

| Method | Path |
|--------|------|
| GET | `/api/proposed-actions` (query: `project_id`) |
| GET | `/api/proposed-actions/all` |
| POST | `/api/proposed-actions/{action_id}/approve` |
| POST | `/api/proposed-actions/{action_id}/reject` |

### Auxiliary agent outputs

| Method | Path |
|--------|------|
| GET | `/api/auxiliary-agent-outputs` (query: `project_id`, optional `agent_role`) |
| POST | `/api/auxiliary-agent-outputs` |

---

## 3. Routes called from exported `static-html/index.html`

Discovered via `api('METHOD', '/…')` usage:

| Method | Path (prefix `/api` implied in code) |
|--------|--------------------------------------|
| GET | `/tasks`, `/projects` |
| POST | `/projects`, `/tasks`, `/projects/{pid}/blueprints`, `/projects/{pid}/decisions`, `/projects/{pid}/requirements`, `/tasks/{id}/complete` |
| PUT | `/projects/{id}`, `/tasks/{id}`, `/projects/{pid}/memory/{key}` |
| PATCH | `/projects/{id}` |
| DELETE | `/projects/{id}`, `/tasks/{id}` |
| GET | `/projects/{projectId}/blueprints`, `/decisions`, `/requirements`, `/session-logs?limit=50`, `/execution-trace`, `/memory`, `/approvals`, `/backlog` |
| GET | `/auxiliary-agent-outputs?project_id=…&agent_role=…` and without `agent_role` |

**Not referenced by `index.html` but implemented:** proposed-actions, validations, runs list, task runs, blueprint get/put/delete by id, session-logs/latest, etc. A new UI may still want them for parity with `AGENTS.md` workflows (e.g. proposed action approval).

---

## 4. Tech stack composer (`static-html/assets/tech-stack-app.js`)

| Method | Path |
|--------|------|
| GET | `/projects`, `/projects/{id}` |
| PUT | `/projects/{id}/tech-stack` |

Payload shape: `selectionsToPayload()` → JSON with nested `selections` by domain / category / item (see file).

---

## 5. React Vite SPA (`react-vite-spa/`)

| File | Legacy behavior | Export behavior |
|------|-----------------|-----------------|
| `vite.config.ts` | Proxied `/api` → `http://127.0.0.1:8765` | Unchanged; update `server.proxy` for your dev API. |
| `src/App.tsx` | `fetch("/api/projects")` | `fetchProjects()` stub returns `[]` — replace with real client. |

---

## 6. State assumptions (monolithic HTML)

- **Global in-memory state:** large sets of `allProjects`, `allTasks`, and tab-specific caches updated after `loadTasks()` and tab loaders.
- **Active project:** selected sidebar project drives which tab fetches run against.
- **Task priority:** UI shows P1–P5; server maps via `_DB_TO_UI` / `_UI_TO_DB` (urgent/high/normal/low). Backend `server.py` maps DB string priorities to integers for JSON responses.
- **Task statuses:** UI labels and CSS tokens align with statuses returned by SQLite services (e.g. `pending`, `in_progress`, `done`, `blocked`, `failed`, etc. — confirm against live API or `task_service`).

---

## 7. Polling / refresh assumptions

- **`loadTasks()`** is invoked on a **`setInterval(..., 30000)`** (30s) timer at the bottom of `index.html`, refreshing the global task/project snapshot.
- Manual refresh controls in the header also call `loadTasks()` (and related render paths).
- **No WebSocket/SSE** in the legacy UI; everything is pull-based.

---

## 8. Components / areas needing rewrite in a component framework

If you split the monolith into React (or similar), natural seams include:

| Area | Notes |
|------|-------|
| Sidebar + project switcher | Owns active `projectId` and counts. |
| Tab panels | `ALL_TABS` list: tasks, blueprints, session logs, execution trace, decisions, requirements, memory, approvals, backlog, audit-trail, auxiliary roles, tech-stack. |
| Task table + modals | CRUD + manual complete. |
| Project admin modal | Create/update/delete/rename slug with confirmation. |
| Auxiliary outputs | One tab per `AUX_ROLE_MAP` role; shared list loader. |
| Tech stack | Already a separate ES module; can stay standalone or be embedded as a route. |

Each tab’s loader should become a **hook or query** with explicit cache keys (e.g. TanStack Query) instead of mutable globals.

---

## 9. Backend contracts to recreate later

Minimum for **parity** with current HTML UX:

1. **Project CRUD** + slug rename + optional `root_path`.
2. **Task CRUD** + filters + manual completion creating/updating runs as today.
3. **Tab payloads:** blueprints, decisions, requirements, memory (keyed), session logs (list + optional latest), execution trace, approvals, backlog, auxiliary outputs.
4. **Tech stack:** GET project row including tech stack field; PUT merged selections.
5. **Proposed actions** (if you keep human-in-the-loop approvals from `AGENTS.md`): list + approve + reject.

Refer to **`architecture-docs/adr/`** and **`architecture-docs/workspace/architecture.md`** for system boundaries and sync rules; OpenAPI was disabled on the legacy server (`docs_url=None`), so this markdown and `server.py` are the schema.

---

## 10. Non-API routes linked from the UI

| Path | Legacy server behavior | Export / static hosting |
|------|------------------------|-------------------------|
| `/` | Serves main `index.html` | Use `static-html/index.html` as default document. |
| `/tech-stack` | Serves `tech-stack.html` | Links in the monolith use absolute `/tech-stack`. For static hosts without rewrites, change links to `tech-stack.html` or configure your CDN/router to alias `/tech-stack` → that file. |
| `/dashboard-assets/*` | Static mount for tech-stack ES modules | **Not used** in this export; assets live under `static-html/assets/` with relative URLs in `tech-stack.html`. |
