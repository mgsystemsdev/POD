# Dashboard UI (exported)

## Layout

| Subfolder | Role |
|-----------|------|
| `static-html/` | **Primary product UI** — single-page `index.html` (~1.8k lines) with embedded CSS and vanilla JS. Tech stack sub-app: `tech-stack.html` + `assets/`. |
| `react-vite-spa/` | **Experimental / secondary shell** — Vite + React + Tailwind; originally proxied `/api` to the FastAPI dashboard. `App.tsx` uses a stub `fetchProjects()` in this export. |

## Serving notes

- **Original runtime:** `server.py` served `/` from `index.html`, `/tech-stack` from `tech-stack.html`, mounted static files at `/dashboard-assets/`, and implemented `/api/*` (see migration notes).
- **This export:** `tech-stack.html` loads `assets/tech-stack-app.js` with a **relative** URL so the folder can be opened from a static host or copied into a new frontend repo. The main `index.html` is still one file; open it through any static server (many browsers block `fetch` from `file://`).
- **API prefix:** both `static-html/index.html` and `static-html/assets/tech-stack-app.js` honor `window.__DASHBOARD_API_PREFIX__` (default `"/api"`). Set it before scripts run if your new backend uses a different base path.

## Source paths in monorepo

All copies trace to `agent-system-base/system/dashboard/` (blueprints). Runtime sync targets `agent-services/system/dashboard/` when `init.sh` is used.
